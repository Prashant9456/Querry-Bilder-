export const userTableData = () => {
  return {
    columnData: [
      {
        name: { value: "", error: "" },
      },
    ],
  };
};
