export const QuerryData = () => {
  return {
    value: { value: "" },
  };
};
export const filterData = () => {
  return {
    select: [],
    filter: [
      {
        dropdownValue: { value: "" },
        columnName: { value: "" },
        oprationData: { value: "" },
        valueData: { value: "" },
      },
    ],
  };
};
