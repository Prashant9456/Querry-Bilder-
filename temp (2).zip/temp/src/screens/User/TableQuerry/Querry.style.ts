import {
  boldFont,
  centerItemFlex,
  customButton1Style,
  getRelativeFontSize,
  mediumFont,
  regularFont,
} from "../../../utils/styles";

const QuerryStyle = {
  customButton1: {
    ...customButton1Style,
    cursor: "pointer",
  },
  fontText: {
    ...regularFont,
  },
  customAddHeader: { justifyContent: "end" },
  dialogFooter: {
    ...centerItemFlex,
    gap: "10px",
    paddingBottom: "20px",
    width: "100%",
    display: "flex",
    justifyContent: "center",
    "& button": {
      width: "120px",
    },
  },
  cancelButtonStyle: {
    color: "#212121 !important",
    backgroundColor: "#FFFFFF",
    border: "1px solid #E7E7E7",
    borderRadius: "10px",
    "&:hover": {
      background: "none",
    },
  },
  textBold: {
    ...boldFont,
    wordBreak: "break-all",
    marginLeft: "5px",
  },
  centerItemFlex: {
    ...centerItemFlex,
    flexDirection: "column",
  },
  wrap: {
    display: "flex",
  },
  modalTitle: {
    ...boldFont,
    fontSize: getRelativeFontSize(13),
    textAlign: "center",
  },
  dropDownStyle: {
    ...regularFont,
    minWidth: "150px",
    height: "47px",
    borderRadius: "15px",
    backgroundColor: "#FFFFFF",
    marginTop: "8px",
  },
  dropDownStyle1: {
    ...regularFont,
    width: "100%",
    height: "47px",
    borderRadius: "15px",
    backgroundColor: "#FFFFFF",
    marginTop: "8px",
  },

  mediumFonts: {
    ...mediumFont,
    cursor: "pointer",
    marginTop: "5px",
    fontSize: getRelativeFontSize(5),
  },
} as const;
export default QuerryStyle;
