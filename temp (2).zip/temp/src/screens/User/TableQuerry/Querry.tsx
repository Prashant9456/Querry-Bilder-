import { TableChart } from "@mui/icons-material";
import {
  Box,
  Chip,
  Grid,
  Icon,
  MenuItem,
  OutlinedInput,
  Select,
  Typography,
  InputLabel,
  FormControl,
} from "@mui/material";
import { useEffect, useState } from "react";
import AddIcon from "@mui/icons-material/Add";
import Header from "../../../global/components/Header/Header";
import QuerryStyle from "./Querry.style";
import ReactSelect, { components } from "react-select";
import { CustomButton } from "../../../global/components";
import CustomDialog from "../../../global/components/CustomDialog/CustomDialog";
import campaignDeleteModal from "../../../assets/images/campaignDeleteModal.svg";
import CustomInput from "../../../global/components/CustomInput/CustomInput";
import { filterData, QuerryData } from "./QuerryValidatin";
export const tableOption = [
  { value: "Id", label: "id" },
  { value: "Phoneno", label: "Phoneno" },
  { value: "name", label: "name" },
  { value: "class", label: "class" },
];
export const tableOptionquerry = [
  { value: "Id", label: "id" },
  { value: "Phoneno", label: "Phoneno" },
  { value: "name", label: "name" },
  { value: "class", label: "class" },
];
export const opration = [
  { value: "NULL", label: "NULL" },
  { value: "NOTNULL", label: "NOT NULL" },
];
export const opration2 = [
  { value: "NULL", label: "NULL" },
  { value: "NOTNULL", label: "NOT NULL" },
  { value: "PRESENT", label: "PRESENT" },
  { value: "BLANK", label: "BLANK" },
  { value: "LIKE", label: "LIKE" },
  { value: "NOTLIKE", label: "NOT LIKE" },
  { value: "IS", label: "IS" },
  { value: "NOT", label: "NOT" },
  { value: "STARTWITH", label: "START WITH" },
  { value: "ENDWITH", label: "END WITH" },
  { value: "IN", label: "IN" },
  { value: "CONTAINS", label: "CONTAINS" },
];
export const opration3 = [
  { value: "NULL", label: "NULL" },
  { value: "NOTNULL", label: "NOT NULL" },
  { value: "IN", label: "IN" },
  { value: "=", label: "=" },
  { value: "!=", label: "!=" },
  { value: ">=", label: ">=" },
  { value: ">", label: ">" },
  { value: "<", label: "<" },
  { value: "<=", label: "<=" },
];
export const condition = [{ value: "AND" }, { value: "OR" }];
export const tablename = [{ value: "employee", label: "employee" }];

const Querry = () => {
  const [deleteName, setDeleteName] = useState<string>();
  // const [selectedOption, setSelectedOption] = useState(null);
  const [openModal, setOpenModal] = useState(false);
  const query = new URLSearchParams(window.location.search);

  const classes = QuerryStyle;
  const [filter, setFilter] = useState<any>(filterData());
  const name = query.get("name");

  const handleChange = (event: any) => {
    const {
      target: { value },
    } = event;

    setFilter({
      ...filter,
      select: [...value],
    });
  };

  const Option = (props: any) => {
    return (
      <div>
        <components.Option {...props}>
          <input
            type="checkbox"
            checked={props.isSelected}
            name="select"
            onChange={() => null}
          />
          <label>{props.label}</label>
        </components.Option>
      </div>
    );
  };

  const handleConfirmExcute = () => {};

  const handleFilterData = (event: any, index: number) => {
    setFilter({
      ...filter,
      filter: [
        ...filter.filter.slice(0, index),
        {
          ...filter.filter[index],
          [event.target.name]: {
            ...filter[event.target.name],
            value: event.target.value,
          },
        },
        ...filter.filter.slice(index + 1),
      ],
    });
  };
  const addUserHeaderContent = () => {
    return <img src={campaignDeleteModal} alt="image not found" />;
  };
  const handleCloseModel = () => {
    setOpenModal(false);
  };
  const addUserDialogFooter = () => {
    return (
      <Grid container sx={classes.centerItemFlex}>
        <Box sx={classes.dialogFooter}>
          <CustomButton
            customClasses={classes.cancelButtonStyle}
            label="Cancel"
            onClick={() => handleCloseModel()}
          />
          <CustomButton
            label="Excute"
            onClick={() => {
              handleConfirmExcute();
            }}
          />
        </Box>
      </Grid>
    );
  };

  const handleaddTask = () => {
    setFilter((prev: any) => {
      return {
        ...prev,
        filter: [
          ...filter.filter,
          {
            dropdownValue: { value: "" },
            columnName: { value: "" },
            oprationData: { value: "" },
            valueData: { value: "" },
          },
        ],
      };
    });
  };

  const dialogContent = () => {
    return (
      <>
        <Box sx={classes.centerItemFlex}>
          <Typography sx={classes.fontText}>
            Are you sure you want to Excute
          </Typography>
        </Box>

        {filter.filter.map((item: any, index: number) => {
          return (
            <>
              <Grid container>
                <Grid xl={12} lg={12} sx={classes.wrap}>
                  <Grid xl={5} lg={5}>
                    <Select
                      sx={classes.dropDownStyle}
                      value={filter.filter[index].dropdownValue.value}
                      name="dropdownValue"
                      onChange={(e: any) => handleFilterData(e, index)}
                    >
                      {tablename.map((data) => (
                        <MenuItem value={data.value}>{data.label}</MenuItem>
                      ))}
                    </Select>
                  </Grid>
                  <Grid xl={5} lg={5}>
                    <Select
                      sx={classes.dropDownStyle}
                      value={filter.filter[index].columnName.value}
                      name="columnName"
                      onChange={(e: any) => handleFilterData(e, index)}
                    >
                      {tableOption.map((data) => (
                        <MenuItem value={data.value}>{data.label}</MenuItem>
                      ))}
                    </Select>
                  </Grid>
                  {filter.filter[index].columnName.value &&
                  typeof filter.filter[index].columnName.value == "string" &&
                  filter.filter[index].columnName.value != "Phoneno" ? (
                    <Grid xl={5} lg={5}>
                      <Select
                        sx={classes.dropDownStyle}
                        value={filter.filter[index].oprationData.value}
                        name="oprationData"
                        onChange={(e: any) => handleFilterData(e, index)}
                      >
                        {opration2.map((data) => (
                          <MenuItem value={data.value}>{data.label}</MenuItem>
                        ))}
                      </Select>
                    </Grid>
                  ) : filter.filter[index].columnName.value &&
                    filter.filter[index].columnName.value == "Phoneno" ? (
                    <Grid xl={5} lg={5}>
                      <Select
                        sx={classes.dropDownStyle}
                        value={filter.filter[index].oprationData.value}
                        name="oprationData"
                        onChange={(e: any) => handleFilterData(e, index)}
                      >
                        {opration3.map((data) => (
                          <MenuItem value={data.value}>{data.label}</MenuItem>
                        ))}
                      </Select>
                    </Grid>
                  ) : (
                    <Grid xl={5} lg={5}>
                      <Select
                        sx={classes.dropDownStyle}
                        value={filter.filter[index].oprationData.value}
                        name="oprationData"
                        onChange={(e: any) => handleFilterData(e, index)}
                      >
                        {opration.map((data) => (
                          <MenuItem value={data.value}>{data.label}</MenuItem>
                        ))}
                      </Select>
                    </Grid>
                  )}
                  {filter.filter[index].columnName.value &&
                  filter.filter[index].oprationData.value != "NULL" &&
                  filter.filter[index].oprationData.value != "NOTNULL" ? (
                    <Grid xl={5} lg={5}>
                      <CustomInput
                        // required
                        // label="Value"
                        varient="standard"
                        value={filter.filter[index].valueData.value}
                        placeHolder="value.."
                        name="valueData"
                        onChange={(e: any) => {
                          handleFilterData(e, index);
                        }}
                        InputProps={{ disableUnderline: true }}
                      />
                    </Grid>
                  ) : undefined}
                </Grid>
              </Grid>
              {filter.filter.length > 1 ? (
                <Grid xl={12} lg={12}>
                  <Select
                    sx={classes.dropDownStyle1}
                    value={filter.filter[index].oprationData.value}
                    name="condition"
                    onChange={(e: any) => handleFilterData(e, index)}
                  >
                    {condition.map((data) => (
                      <MenuItem value={data.value}>{data.value}</MenuItem>
                    ))}
                  </Select>
                </Grid>
              ) : null}
            </>
          );
        })}
        <Grid container sx={classes.customAddHeader}>
          <button onClick={handleaddTask}>
            <AddIcon />
          </button>
        </Grid>
      </>
    );
  };

  const dialogTitleContent = () => {
    return (
      <>
        <Typography sx={classes.modalTitle}>Excute </Typography>
      </>
    );
  };

  const customDialog = () => {
    return (
      <>
        <CustomDialog
          isDialogOpen={openModal}
          closable
          handleDialogClose={handleCloseModel}
          dialogTitleContent={dialogTitleContent()}
          dialogBodyContent={dialogContent()}
          // dialogHeaderContent={addUserHeaderContent()}
          dialogFooterContent={addUserDialogFooter()}
          width="800px"
          closeButtonVisibility
        />
      </>
    );
  };
  const handleFilter = (name: string) => {
    setDeleteName(name);
    setOpenModal(true);
  };
  const handleJoin = () => {};
  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };
  const getLeftSideData = () => {
    return (
      <>
        <Grid item xs={12} sm={3} bgcolor="#FFFFFF">
          <Box>
            <Typography sx={classes.mediumFonts}>
              <Icon color="primary" fontSize="large">
                <TableChart fontSize="small" sx={{ color: "black" }} />
              </Icon>
              {name}
            </Typography>

            <Typography sx={classes.mediumFonts}>Select</Typography>

            <FormControl sx={{ m: 1, width: "95%" }}>
              <InputLabel id="demo-multiple-chip-label">Select</InputLabel>
              <Select
                labelId="demo-multiple-chip-label"
                id="demo-multiple-chip"
                multiple
                value={filter.select}
                onChange={handleChange}
                input={
                  <OutlinedInput id="select-multiple-chip" label="Select" />
                }
                renderValue={(selected: any) => (
                  <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                    {selected.map((value: any, index: number) => (
                      <Chip key={value} label={value} />
                    ))}
                  </Box>
                )}
                MenuProps={MenuProps}
              >
                {tableOption.map((name: any) => (
                  <MenuItem key={name.value} value={name.value}>
                    {name.value}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>
          <Box>
            <Typography sx={classes.mediumFonts}>Filters</Typography>
            <CustomButton
              onClick={handleFilter}
              variant="outlined"
              customClasses={classes.customButton1}
              icon={<AddIcon />}
            />
          </Box>
          <Box>
            <Typography sx={classes.mediumFonts}>Join</Typography>
            <CustomButton
              onClick={handleJoin}
              variant="outlined"
              customClasses={classes.customButton1}
              icon={<AddIcon />}
            />
          </Box>
          <Box>
            <Typography sx={classes.mediumFonts}>Short</Typography>
            <CustomButton
              onClick={handleJoin}
              variant="outlined"
              customClasses={classes.customButton1}
              icon={<AddIcon />}
            />
          </Box>
          <Box>
            <Typography sx={classes.mediumFonts}>Summarize</Typography>
            <CustomButton
              onClick={handleJoin}
              variant="outlined"
              customClasses={classes.customButton1}
              icon={<AddIcon />}
            />
          </Box>
          <Box>
            <Typography sx={classes.mediumFonts}>Group By</Typography>
            <CustomButton
              onClick={handleJoin}
              variant="outlined"
              customClasses={classes.customButton1}
              icon={<AddIcon />}
            />
          </Box>
          <Box>
            <Typography sx={classes.mediumFonts}>Limit</Typography>
            <CustomButton
              onClick={handleJoin}
              variant="outlined"
              customClasses={classes.customButton1}
              icon={<AddIcon />}
            />
          </Box>
        </Grid>
      </>
    );
  };

  const getValue = () => {
    return (
      <>
        <Header />

        <Grid
          container
          spacing={4}
          sx={{ paddingTop: "64px", height: "100vh", overflow: "auto" }}
        >
          {getLeftSideData()}
          {/* {RightSideData()} */}
          {customDialog()}
        </Grid>
      </>
    );
  };

  return getValue();
};

export default Querry;
