import { getRelativeFontSize, mediumFont } from "../../utils/styles";

const UserStyle = {
  mediumFonts: {
    ...mediumFont,
    cursor: "pointer",
    fontSize: getRelativeFontSize(5),
  },
};
export default UserStyle;
