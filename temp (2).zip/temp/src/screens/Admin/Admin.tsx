import { Box, Divider, Grid, Typography } from "@mui/material";
import React, { useState } from "react";
import { CustomButton, CustomPaper } from "../../global/components";
import CustomDialog from "../../global/components/CustomDialog/CustomDialog";
import AdminStyle from "./Admin.style";
import history from "../../utils/history";
import urls from "../../global/constants/UrlConstants";
import CustomInput from "../../global/components/CustomInput/CustomInput";
import { insertschemaField } from "./AddTable/AddTableValidation";
import Header from "../../global/components/Header/Header";
const Admin = () => {
  const classes = AdminStyle;
  const [tableData, setTableData] = useState<any>(insertschemaField());
  const [schemaData, setSchemaData] = useState<any>([
    {
      tableName: {
        name: "Employee",
        id: "25",
        column: "5",
      },
    },
    {
      tableName: {
        name: "Student",
        id: "10",
        column: "4",
      },
    },
  ]);
  const handleState = (event: React.ChangeEvent<any>) => {
    // sessionStorage.clear();
    setTableData({
      ...tableData,
      [event.target.name]: {
        ...tableData[event.target.name],
        value: event.target.value,
      },
    });
  };
  const handleClick = (name: string) => {};
  console.log(schemaData);
  const ShowData = () => {
    return (
      <>
        <Box sx={classes.paperWraper}>
          {schemaData.map((item: any, index: number) => {
            return (
              <>
                <CustomPaper
                  key={index}
                  className={classes.paperStyle}
                  onClick={() => handleClick(item.name)}
                >
                  <Grid container>
                    <Grid
                      item
                      sx={classes.squareBox}
                      xs={2}
                      sm={2}
                      md={2}
                      lg={2}
                      xl={2}
                    >
                      <Typography sx={classes.avatarStyle}>
                        {item.tableName.name.charAt(0).toUpperCase()}
                      </Typography>
                    </Grid>
                    <Divider
                      orientation="vertical"
                      flexItem
                      sx={classes.dividerStyleV}
                    />
                    <Grid
                      item
                      xs={9}
                      sm={9}
                      md={9}
                      lg={9}
                      xl={9}
                      sx={classes.clientName}
                    >
                      <Typography sx={classes.cardHeader}>
                        {item.tableName.name}
                        {console.log(item.tableName.name)}
                      </Typography>
                    </Grid>
                  </Grid>
                  <Divider sx={classes.dividerStyle} />
                  <Grid container pt={1}>
                    <Grid
                      item
                      xs={12}
                      sm={12}
                      md={12}
                      lg={12}
                      xl={12}
                      sx={classes.contentBox}
                    >
                      <Typography sx={classes.cardTitles}>Id</Typography>
                      <Typography sx={classes.cardContent}>
                        {item.tableName.id}
                      </Typography>
                    </Grid>
                    <Grid
                      item
                      xs={12}
                      sm={12}
                      md={12}
                      lg={12}
                      xl={12}
                      sx={classes.contentBox}
                    >
                      <Typography sx={classes.cardTitles}>Column</Typography>
                      <Typography sx={classes.cardContent}>
                        {item.tableName.column}
                      </Typography>
                    </Grid>
                  </Grid>
                </CustomPaper>
              </>
            );
          })}
        </Box>
      </>
    );
  };
  // const data = sessionStorage.getItem("schemaname");
  const CreateTable = () => {
    const handleCreateTable = () => {
      if (tableData.tableschemaname) {
        // sessionStorage.setItem("schemaname", tableData.tableschemaname.value);
        return history.push(urls.addTable);
      }
    };
    return (
      <>
        <Box>
          <Grid container>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <Box ml={5} mr={5} mt={3}>
                <CustomInput
                  required
                  label="Table Name"
                  varient="standard"
                  name="tableschemaname"
                  onChange={handleState}
                  // value={data}
                  InputProps={{ disableUnderline: true }}
                />
              </Box>
            </Grid>
          </Grid>
          <Grid container sx={classes.saveButton}>
            <Grid item xs={12} sm={5} md={6} lg={5} xl={3}>
              <Box mr={5} ml={5} mt={3}>
                <CustomButton onClick={handleCreateTable} label="CreateTable" />
              </Box>
            </Grid>
          </Grid>
        </Box>
      </>
    );
  };
  const AdminData = () => {
    return (
      <>
        <Header />
        <Box mt={15}>
          {CreateTable()}
          {ShowData()}
        </Box>
      </>
    );
  };

  return AdminData();
};

export default Admin;
