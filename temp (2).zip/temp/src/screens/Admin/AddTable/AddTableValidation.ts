export const inserttableField = () => {
  return {
    columnData: [
      {
        name: { value: "", error: "" },
        type: { value: "", error: "" },
      },
    ],
  };
};

export const insertschemaField = () => {
  return {};
};
