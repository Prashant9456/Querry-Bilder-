import {
  Box,
  Grid,
  InputLabel,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { CustomButton } from "../../../global/components";
import AddIcon from "@mui/icons-material/Add";
import CustomInput from "../../../global/components/CustomInput/CustomInput";
import AdminStyle from "../Admin.style";
import { inserttableField } from "./AddTableValidation";
import history from "../../../utils/history";
import CustomDialog from "../../../global/components/CustomDialog/CustomDialog";
import campaignDeleteModal from "../../../../src/assets/images/deleteImage.png";
import urls from "../../../global/constants/UrlConstants";
import Header from "../../../global/components/Header/Header";

const AddTable = () => {
  const classes = AdminStyle;
  const [tableData, setTableData] = useState<any>(inserttableField());
  const [openModal, setOpenModal] = useState(false);
  const [schemaname, setSchemaname] = useState<string>();

  console.log(tableData);
  const handleState = (event: React.ChangeEvent<any>, index: number) => {
    setTableData({
      ...tableData,
      columnData: [
        ...tableData.columnData.slice(0, index),
        {
          ...tableData.columnData[index],
          [event.target.name]: {
            ...tableData[event.target.name],
            value: event.target.value,
          },
        },
        ...tableData.columnData.slice(index + 1),
      ],
    });
  };

  const handleAddCustom = () => {
    setTableData((prev: any) => {
      return {
        ...prev,
        columnData: [...tableData.columnData, { name: "", type: "" }],
      };
    });
  };
  const handleCloseModel = () => {
    setOpenModal(false);
  };
  const dialogTitleContent = () => {
    return (
      <>
        <Typography sx={classes.modalTitle}>Add More Table</Typography>
      </>
    );
  };
  const dialogContent = () => {
    return (
      <>
        <Box sx={classes.centerItemFlex}>
          <Typography sx={classes.fontText}>
            Are you sure you want to ADD
          </Typography>
        </Box>
      </>
    );
  };
  const addUserHeaderContent = () => {
    return <img src={campaignDeleteModal} alt="image not found" />;
  };
  const handleConfirmAdd = async (name: any) => {
    setOpenModal(false);
    history.push(urls.AdminViewPath);
  };
  const addUserDialogFooter = () => {
    return (
      <Grid container sx={classes.centerItemFlex}>
        <Box sx={classes.dialogFooter}>
          <CustomButton
            customClasses={classes.cancelButtonStyle}
            label="Cancel"
            onClick={() => handleCloseModel()}
          />
          <CustomButton
            label="ADD"
            onClick={() => {
              handleConfirmAdd(schemaname);
            }}
          />
        </Box>
      </Grid>
    );
  };
  const handleSave = (name: string) => {
    setSchemaname(name);
    setOpenModal(true);
  };
  const handleSaveDialog = () => {
    return (
      <CustomDialog
        isDialogOpen={openModal}
        closable
        handleDialogClose={handleCloseModel}
        dialogTitleContent={dialogTitleContent()}
        dialogBodyContent={dialogContent()}
        dialogHeaderContent={addUserHeaderContent()}
        dialogFooterContent={addUserDialogFooter()}
        width="460px"
        closeButtonVisibility
      />
    );
  };

  const getValue = () => {
    return (
      <>
        <Grid container>
          {tableData.columnData.map((item: string, index: number) => (
            <>
              <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
                <Box ml={5} mr={5} mt={3}>
                  <CustomInput
                    required
                    label="Name"
                    varient="standard"
                    name="name"
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      handleState(e, index);
                    }}
                    InputProps={{ disableUnderline: true }}
                    value={tableData.columnData[index].name.value}
                    // error={
                    //   !isTruthy(appPlanData.name.value) && appPlanData.name.error
                    // }
                  />
                </Box>
              </Grid>
              <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
                <Box ml={5} mr={5} mt={3}>
                  <CustomInput
                    required
                    label="Type"
                    varient="standard"
                    name="type"
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      handleState(e, index);
                    }}
                    InputProps={{ disableUnderline: true }}
                    value={tableData.columnData[index].type.value}
                    // error={
                    //   !isTruthy(appPlanData.name.value) && appPlanData.name.error
                    // }
                  />
                </Box>
              </Grid>
            </>
          ))}
        </Grid>

        <Grid container sx={classes.customAddHeader}>
          <Grid item xs={12} sm={3.5} md={3} lg={2} xl={1.5} mr={5} ml={5}>
            <CustomButton
              onClick={handleAddCustom}
              variant="outlined"
              customClasses={classes.customButton1}
              icon={<AddIcon />}
              label="Add tasks"
            />
          </Grid>
        </Grid>
      </>
    );
  };
  const getSaveButton = () => {
    return (
      <Grid container sx={classes.saveButton}>
        <Grid item xs={12} sm={5} md={6} lg={5} xl={3}>
          <Box mr={5} ml={5} mt={3}>
            <CustomButton onClick={handleSave} label="Save" />
          </Box>
        </Grid>
      </Grid>
    );
  };
  const getAdmin = () => {
    return (
      <>
        <Header />
        <Box mt={5}>
          {getValue()}
          {getSaveButton()}
          {handleSaveDialog()}
        </Box>
      </>
    );
  };
  return getAdmin();
};

export default AddTable;
