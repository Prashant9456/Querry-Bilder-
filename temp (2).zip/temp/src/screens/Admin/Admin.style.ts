import {
  boldFont,
  centerItemFlex,
  customButton1Style,
  getRelativeFontSize,
  inputLabelRequiredColor,
  mediumFont,
  regularFont,
} from "../../utils/styles";

const AdminStyle = {
  modalTitle: {
    ...boldFont,
    fontSize: getRelativeFontSize(13),
    textAlign: "center",
    background: "#F5F5F5",
  },
  nameField: {
    ...boldFont,
    color: "#0D3057",
    "& .MuiFormLabel-asterisk": {
      color: inputLabelRequiredColor,
    },
  },
  textField: {
    "& fieldset": { border: "none" },
    width: "100%",
    borderRadius: "10px",
    background: "#ffffff",
    "& .MuiInputBase-input": {
      position: "relative",
      padding: "12px 12px",
      "&::placeholder": {
        ...mediumFont,
      },
    },
    "& .MuiOutlinedInput-root": {
      borderRadius: "10px",
    },
  },
  mediumFonts: {
    ...mediumFont,
    fontSize: getRelativeFontSize(5),
  },
  fontText: {
    ...regularFont,
  },
  dialogFooter: {
    ...centerItemFlex,
    gap: "10px",
    paddingBottom: "20px",
    width: "100%",
    display: "flex",
    justifyContent: "center",
    "& button": {
      width: "120px",
    },
  },
  cancelButtonStyle: {
    color: "#212121 !important",
    backgroundColor: "#FFFFFF",
    border: "1px solid #E7E7E7",
    borderRadius: "10px",
    "&:hover": {
      background: "none",
    },
  },
  centerItemFlex: {
    ...centerItemFlex,
    flexDirection: "column",
  },
  saveButton: {
    marginTop: "20px",
    marginBottom: "30px",
    justifyContent: "center",
  },
  customAddHeader: { justifyContent: "end", marginTop: "25px" },
  customButton1: {
    ...customButton1Style,
  },
  paperStyle: {
    cursor: "pointer",
    p: 2,
    backgroundColor: "#ffffff",
    margin: "10px",
    textAlign: "center",
    borderRadius: "15px",
    boxShadow:
      "0px 2px 1px -1px rgb(0 0 0 / 0%), 0px 1px 1px 0px rgb(0 0 0 / 0%), 0px 1px 3px 0px rgb(0 0 0 / 5%)",
    width: "100%",
    maxWidth: "320px",
    height: "auto",
    direction: "row",
  },
  squareBox: {
    width: "46px",
    height: "46px",
    borderRadius: "15px",
    background: "#113964",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  avatarStyle: {
    ...boldFont,
    color: "white",
    fontSize: getRelativeFontSize(10),
  },
  dividerStyleV: {
    paddingLeft: "10px",
  },
  clientName: { alignSelf: "center" },
  cardHeader: {
    fontWeight: "bold",
    fontSize: "15px",
  },
  dividerStyle: {
    width: "100%",
    marginTop: "8px",
  },

  contentBox: {
    display: "flex",
    justifyContent: "space-between",
  },
  cardTitles: {
    fontWeight: "bold",
    color: "#666666",
    fontSize: "14px",
  },
  cardContent: {
    fontSize: "15px",
  },
  paperWraper: {
    display: "flex",
    // justifyContent: "center",
    flexWrap: "wrap",
    marginLeft: "20px",
  },
} as const;
export default AdminStyle;
