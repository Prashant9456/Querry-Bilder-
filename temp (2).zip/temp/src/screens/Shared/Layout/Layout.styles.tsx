const layoutStyles = {
  content: {
    flexGrow: 1,
    padding: 3,
    backgroundColor: "#F7F7F7",
  },
} as const;

export default layoutStyles;
