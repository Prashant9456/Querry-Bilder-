import { mediumFont, primaryColor } from "../../utils/styles";

const landingPageStyles = {
  mainContainer: {
    // backgroundColor: primaryColor,
    width: "100vw",
    height: "100vh",
  },
  radiusLeft: {
    borderLeft: "none",
    borderRadius: "0px 13px 13px 0px",
    boxShadow: "rgb(0 0 0 / 5%) 6px 0px 15px 1px",
    width: "100%",
    paddingTop: "10px",
    paddingRight: "10px",
  },
  boxImage: {
    display: "flex",
    height: "100%",
  },
  footer: {
    position: "fixed",
    bottom: 50,
    alignItems: "center",
    left: "50%",
    transform: " translate(-50%, 0)",
    width: "50%",
  },
  footerTypo: {
    ...mediumFont,
    textAlign: "center",
  },
  mainGrid: {
    margin: "100px auto",
  },
  radiusRight: {
    borderRadius: "13px 0px 0px 13px",
    border: "none",
    boxShadow: "rgb(0 0 0 / 5%) -6px 0px 15px 1px",
    width: "100%",
  },
} as const;

export default landingPageStyles;
