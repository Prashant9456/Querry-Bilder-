import {
  boldFont,
  inputLabelRequiredColor,
  mediumFont,
} from "../../../utils/styles";

const customInputStyles = {
  textField: {
    width: "100%",
    borderRadius: "10px",
    background: "#ffffff",
    "& .MuiInputBase-input": {
      position: "relative",
      padding: "12px 12px",
      "&::placeholder": {
        ...mediumFont,
      },
    },
    "& .MuiOutlinedInput-root": {
      borderRadius: "10px",
      "&.Mui-focused fieldset": {
        borderColor: "#ffffff",
      },
    },
    "&::-webkit-outer-spin-button, &::-webkit-inner-spin-button": {
      "-webkit-appearance": "none",
      display: "none",
    },
    // "& .MuiFormHelperText-root": {
    //   backgroundColor: "#F5F5F5",
    // },
  },
  errorStyle: {
    fontSize: "0.75rem",
    color: "#d32f2f",
  },
  nameField: {
    ...boldFont,
    color: "#0D3057",
    "& .MuiFormLabel-asterisk": {
      color: inputLabelRequiredColor,
    },
  },
} as const;

export default customInputStyles;
