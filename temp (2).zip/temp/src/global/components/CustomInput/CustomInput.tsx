import { Box, InputLabel, SxProps, TextField } from "@mui/material";
import customInputStyles from "./CustomInput.styles";

interface CustomProps {
  label?: string;
  placeHolder?: string;
  value?: string | any;
  onChange?: any;
  type?: string;
  name?: string;
  select?: boolean;
  onKeyPress?: any;
  InputProps?: any;
  error?: any;
  required?: boolean;
  InputLabelProps?: any;
  id?: string;
  sx?: SxProps;
  disabled?: boolean;
  propsToInputElement?: any;
  varient?: "filled" | "standard" | "outlined" | undefined;
}

const CustomInput = (props: CustomProps) => {
  const classes = customInputStyles;
  const { error = null } = props;

  return (
    <Box>
      <Box mb={1}>
        <InputLabel required={props.required} sx={classes.nameField}>
          {props.label}
        </InputLabel>
      </Box>
      <TextField
        sx={classes.textField}
        variant={props.varient}
        id={props.id}
        placeholder={props.placeHolder}
        type={props.type}
        name={props.name}
        select={props.select}
        value={props.value}
        InputProps={props.InputProps}
        inputProps={props.propsToInputElement}
        onChange={props.onChange}
        onKeyPress={props.onKeyPress}
        required={props.required}
        // {...(error && { error: true, helperText: error })}
        disabled={props.disabled}
      />
      {error && <span style={classes.errorStyle}>{error}</span>}
    </Box>
  );
};

export default CustomInput;
