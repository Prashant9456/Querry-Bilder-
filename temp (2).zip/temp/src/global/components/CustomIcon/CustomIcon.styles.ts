import { centerItemFlex } from "../../../utils/styles";

const customIconStyles = {
  centerAlignedBox: {
    ...centerItemFlex,
  },
} as const;

export default customIconStyles;
