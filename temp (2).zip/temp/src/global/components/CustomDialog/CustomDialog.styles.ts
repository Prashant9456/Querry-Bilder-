import { Theme } from "@mui/material";
import { makeStyles } from "@mui/styles";

const customDialogStyles = makeStyles((theme: Theme) => ({
  headerStyle: {
    background: "#0d3057",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "20px 0 0 0",
    position: "relative",
    width: "100%",
  },
  dialogTitle: {
    margin: 0,
    padding: theme.spacing(2),
    display: "flex",
    flexDirection: "column",
    background: "#F5F5F5",
  },
  closeButtonContainer: {
    position: "absolute",
    top: "15px",
    right: "15px",
    color: theme.palette.grey[500],
  },
  closeButton: {
    padding: 0,
    marginTop: "9px",
    marginRight: "5px",
    color: "#ffffff",
  },
  dialogContent: {
    padding: theme.spacing(2),
    background: "#F5F5F5",
  },
  dialogActions: {
    margin: 0,
    padding: theme.spacing(1, 2),
    display: "flex",
    background: "#F5F5F5",
  },
  displayFlex: {
    display: "flex",
  },
}));

export default customDialogStyles;
