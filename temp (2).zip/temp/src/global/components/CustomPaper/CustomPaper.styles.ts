const customPaperStyles = {
  customPaper: {
    borderRadius: "13px",
  },
  customPaperMobile: {
    border: "none",
  },
} as const;

export default customPaperStyles;
