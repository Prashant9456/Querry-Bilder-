import React from "react";
import customPaperStyles from "./CustomPaper.styles";
import { Paper } from "@mui/material";

interface CustomProps {
  children: React.ReactNode;
  className?: any;
  isWeb?: boolean;
  removeBorder?: boolean;
  onClick?: any;
}

const CustomPaper = (props: CustomProps) => {
  const classes = customPaperStyles;
  if (props.removeBorder) {
    if (!props.isWeb) {
      return (
        <Paper
          variant="outlined"
          onClick={props.onClick}
          sx={[classes.customPaperMobile, props.className]}
        >
          {props.children}
        </Paper>
      );
    }
  }
  return (
    <Paper
      variant="outlined"
      sx={[classes.customPaper, props.className]}
      onClick={props.onClick}
    >
      {props.children}
    </Paper>
  );
};

export default CustomPaper;
