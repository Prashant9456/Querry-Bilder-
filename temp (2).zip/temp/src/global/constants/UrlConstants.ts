import { StringConstants } from "./StringConstants";

class UrlConstants extends StringConstants {
  PROD = false;

  url_prod = "<PROD_BACKEND_URL>";
  // url_dev = "<DEV_BACKEND_URL>";
  url_dev = "http://localhost:3000";

  url = this.PROD ? this.url_prod : this.url_dev;

  // View Paths
  landingViewPath = "/";
  loginViewPath = "/login";

  // Base Folders
  // auth = "auth";

  // Endpoint
  REFRESHTOKEN = `${this.url}/auth/refreshToken`;

  UserViewPath = "/User";
  AdminViewPath = `/Admin`;
  addTable = "/Add";
  userTableShort = `${this.UserViewPath}/edit`;
}

let urls = new UrlConstants();
export default urls;
